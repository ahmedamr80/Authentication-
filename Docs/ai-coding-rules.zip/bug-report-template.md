# Bug Report Template — paste this back to the AI when you hit an error
# (forces it to respect the surrounding system instead of blindly patching)

### 🚨 Bug Report & Context

#### 1. The Error Message / Unexpected Behavior
```text
[paste the FULL stack trace / console error / description here]
```

#### 2. The Active Code / File In Question
```python
# paste the exact function or block causing the issue
```

#### 3. Expected vs Actual
- **Expected:** [what should happen]
- **Actual:** [what happens instead]

#### 4. Critical Dependencies (Do Not Break!)
- **Adjacent features:** [e.g., "auth state must persist after this DB call resets"]
- **Downstream consumers:** [e.g., "returns a tuple used by the renderer — do not change the return type"]
- **Shared state / types:** [anything that touches this code path]

#### 5. Constraints for the fix
- [ ] Change only what's needed to fix this error
- [ ] Do not refactor, rename, or clean up unrelated code
- [ ] Public signatures (types/props/API shape) must stay identical
- [ ] List what you deliberately did NOT touch in your answer
