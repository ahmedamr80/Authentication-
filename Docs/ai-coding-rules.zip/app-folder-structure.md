# Example App Folder Structures

## 1. Full-stack web app (Next.js / React + API)
```
my-app/
├── CLAUDE.md / .cursor/rules/     ← AI rules live here
├── .claude/
│   ├── settings.json              ← hooks config
│   └── hooks/                     ← post-edit checks, test gates
├── src/
│   ├── app/ (or pages/)           ← routes
│   ├── components/
│   │   ├── ui/                    ← buttons, inputs (dumb, reusable)
│   │   └── features/              ← feature-specific components
│   ├── hooks/                     ← useAuth, useDebounce, useFetch
│   ├── lib/ (or services/)        ← API clients, business logic
│   ├── stores/                    ← state (zustand/redux)
│   ├── types/                     ← shared TypeScript types/schemas
│   ├── utils/                     ← pure helpers (formatDate, cn)
│   └── config/                    ← env parsing, constants
├── tests/ (or colocated *.test.*)
├── docs/                          ← ADRs, architecture notes
└── scripts/                       ← seed, migrate, generate
```
Rule of thumb: **a file only imports from layers below it** (components → hooks → lib → types/utils). Never backwards.

## 2. Python / FastAPI backend
```
api/
├── app/
│   ├── main.py
│   ├── routers/        ← one router per domain (users.py, orders.py)
│   ├── services/       ← business logic (no HTTP objects here)
│   ├── models/         ← DB models
│   ├── schemas/        ← Pydantic request/response
│   ├── dependencies/   ← auth, db session injection
│   └── core/           ← config, logging, exceptions
├── tests/
└── alembic/
```

## 3. Shared conventions for all structures
- **Colocate by feature when a feature is big**; layer-based folders when small.
- `types/` (or schemas) is the contract layer — signatures there change rarely
  and only with a migration. This is the #1 regression source: protect it.
- One export per concern; no 1,000-line "utils.js" grab-bags.
