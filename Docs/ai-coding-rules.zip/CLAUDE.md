# Project AI Coding Rules (paste at project root, or feed at session start)

## CRITICAL RULES — FUNCTIONALITY PRESERVATION (read first, applies to EVERY task)
1. **Preserve all existing functionality.** When fixing a bug, refactoring, or optimizing,
   the ONLY allowed behavior change is the bug fix itself. Everything else must work
   exactly as before.
2. **Impact assessment before editing.** Before changing any function/class/prop,
   trace its dependencies (callers, imports, shared state, UI elements). List what
   depends on it, mentally or in a comment.
3. **No deletion of "redundant-looking" code.** Code that looks unused often handles
   an edge case, a legacy prop, or a migration path. Do not remove or rewrite it
   unless explicitly instructed.
4. **Isolated fixes only.** Localize the change to the smallest possible scope.
   NO unrelated refactoring, renaming, reformatting, or "cleanup" while fixing an error.
5. **No signature changes.** Do not change function/return types, prop interfaces,
   DB schemas, or API response shapes unless fixing the bug REQUIRES it — and if it
   does, flag it loudly and update all call sites.
6. **No new control flags or global state.** Fix the edge case inside the existing
   logic; don't thread new booleans/contexts through the app.
7. **If unsure — ASK, don't guess.** Especially before deleting anything.

## Error-Fixing Workflow (mandatory when an error is reported)
1. Reproduce & isolate: identify the exact failing function/line. No blind rewrites.
2. Blast radius: list every file/feature that shares state, variables, or types
   with the broken block. Treat them as "do not break" zones.
3. Minimal targeted patch: change only what resolves the reported error.
4. Regression checklist: after the fix, verify these still work:
   - The original failing case is fixed ✔
   - Adjacent features that use the same function/module ✔
   - Features you did NOT touch still behave identically ✔
   - Types/schemas/API contracts unchanged (or explicitly migrated) ✔
5. Report the diff summary: what changed, what was deliberately left untouched.

## Coding Standards
- Strict type safety: type hints / TypeScript strict mode on all new code.
- Guard clauses & early returns instead of deep nesting.
- One task per session/turn. No unrelated changes bundled with a fix.
- Small diffs: one file → verify → next file.

## Verification
- Run tests (or the smallest relevant check) after EVERY code change.
- If tests don't exist for the touched code, say so — don't claim it works.
