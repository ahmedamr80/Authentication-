#!/usr/bin/env python3
"""Post-edit safety hook: after any file edit, run fast static checks
and warn about accidental public-signature changes (git diff scan).

This hook NEVER blocks — it only warns, so you keep control.
""\""
import subprocess, sys, re

ROOT = sys.argv[1] if len(sys.argv) > 1 else "."

def run(cmd):
    try:
        return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=60)
    except Exception:
        return None

def main():
    warnings = []

    # 1. TypeScript / Python fast checks (whichever exists)
    if run(["test", "-f", "tsconfig.json"]):
        r = run(["npx", "tsc", "--noEmit"])
        if r and r.returncode != 0:
            warnings.append("TypeScript errors introduced:\n" + r.stdout[:2000])
    if run(["test", "-f", "pyproject.toml"]):
        r = run(["python", "-m", "mypy", ".", "--ignore-missing-imports"])
        if r and r.returncode != 0:
            warnings.append("Type errors introduced:\n" + r.stdout[:2000])

    # 2. Signature-change scan in the staged/working diff
    r = run(["git", "diff", "--unified=0"])
    if r and r.returncode == 0:
        diff = r.stdout
        sig_re = re.compile(r"^-.*(def \w+\(|=>|function \w+|interface \w+|class \w+)")
        changed = sig_re.findall(diff)
        removed = re.findall(r"^-\s*(def \w+\(|interface \w+|class \w+|export \w+)", diff, re.M)
        if removed:
            warnings.append("PUBLIC SIGNATURES REMOVED/MODIFIED (verify this is intended):\n" + "\n".join(removed[:20]))

    if warnings:
        print("\n\n⚠️  POST-EDIT SAFETY WARNINGS ⚠️\n" + "\n---\n".join(warnings))
    else:
        print("post_edit_check: OK")

if __name__ == "__main__":
    main()
