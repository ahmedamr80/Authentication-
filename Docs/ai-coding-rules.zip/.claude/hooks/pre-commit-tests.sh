#!/usr/bin/env bash
# Pre-commit gate: refuse to commit while tests fail.
# Install: cp to .git/hooks/pre-commit && chmod +x
set -e
echo "Running test gate..."
if [ -f package.json ]; then
  npm test -- --runInBand
elif [ -f pyproject.toml ]; then
  python -m pytest -x -q
else
  echo "No test runner detected — skipping gate."
fi
echo "Test gate passed."
