# AI Coding Rules Pack

Feed `CLAUDE.md` (or the `.cursor/rules/*.mdc` files) to your AI coding tool
at the start of every session. They encode the #1 rule you asked for:

> **Fixing a bug must never break something else.**

## Files
| File | Purpose |
|---|---|
| `CLAUDE.md` | Master rules: functionality preservation + error-fix workflow |
| `.cursor/rules/error-fixes.mdc` | Auto-activates on bug-fix tasks (Cursor) |
| `.cursor/rules/code-optimization.mdc` | Optimize without changing behavior |
| `.cursor/rules/error-handling-ux.mdc` | Error messages for users AND developers |
| `bug-report-template.md` | Paste this back to the AI with any error |
| `.claude/settings.json` + hooks | Test-gate on commits, post-edit signature checks |
| `app-folder-structure.md` | Reference app folder layouts |

## Usage
- **Claude Code**: put `CLAUDE.md` + `.claude/` in project root. Done — auto-loaded.
- **Cursor**: put `.cursor/rules/` in project root. Done.
- **Any chat**: paste `CLAUDE.md` + the relevant `.mdc` content + `bug-report-template.md` filled in.
