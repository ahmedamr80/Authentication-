# User-Facing Errors and Technical Diagnostics

## Goals

A user-facing error should tell the user what happened at a useful level, what they can do next, and whether their action succeeded. Technical diagnostics should help developers investigate without leaking sensitive implementation details.

## Message rules

- Use plain language and a specific next step when one exists.
- Preserve form input after a failed submission whenever safe and appropriate.
- Distinguish validation, authentication, authorization, conflict/business-rule, network, and unexpected errors.
- Do not show raw stack traces, SQL/Firestore query details, internal paths, tokens, secrets, security-rule internals, or raw exception messages.
- Do not say an action succeeded until the backend confirms success.
- Do not silently treat a failed request as a successful empty result.
- Offer a retry only when retrying is safe; avoid duplicate payments, registrations, invitations, writes, or notifications.
- For permissions, explain that the user does not have access and what legitimate next step is available; do not disclose protected records.

## Examples

| Situation | Better user-facing message | Avoid |
|---|---|---|
| Required field missing | “Enter your email address to continue.” | “Invalid input.” |
| Network failure | “We couldn't connect. Check your connection and try again.” | “TypeError: Failed to fetch at api.ts:42” |
| Permission denied | “You don't have permission to make this change. Contact an administrator if you think this is a mistake.” | Raw backend/security-rule error |
| Duplicate action/conflict | “This item has already been submitted. Refresh the page to see the latest status.” | “Write failed: already-exists” |
| Unexpected failure | “Something went wrong while saving. Your changes may not have been saved. Please check the status before trying again.” | Raw exception text or false success |
| Search with no matches | “No players found. Try a different name.” | Showing it as a server error |

Adapt messages to the actual behavior. For example, do not tell users their changes were saved if the app cannot confirm it.

## Error-handling pattern

1. Detect and classify expected errors near the boundary where they are understood.
2. Return a safe, typed result or throw an error for the caller to handle according to existing project conventions.
3. Let the UI display a clear message and a relevant recovery action.
4. Log unexpected technical details only to an approved diagnostic channel, with appropriate access controls and redaction.
5. Avoid logging passwords, tokens, secrets, or unnecessary personal data.
6. Test the error path as carefully as the success path.

## Example type

```ts
export type AppErrorCode =
  | "VALIDATION"
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "CONFLICT"
  | "NETWORK"
  | "UNEXPECTED";

export type AppError = {
  code: AppErrorCode;
  userMessage: string;
  retryable: boolean;
  correlationId?: string;
};
```

This is a starting shape, not a mandate to wrap every exception. Reuse an existing project error model if one already exists. Keep developer-only details separate from `userMessage`.

## Logging checklist

- [ ] Error has enough context to troubleshoot (operation, safe record reference, timestamp, correlation ID where available).
- [ ] Sensitive values and secrets are excluded or redacted.
- [ ] Logs are not publicly exposed.
- [ ] Expected user mistakes are not unnecessarily logged as severe system failures.
- [ ] User receives a safe and actionable message.
