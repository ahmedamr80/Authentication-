# Bug Fix Protocol: Fix the Cause Without Breaking Other Features

## Required steps

### 1. Reproduce and define

Write down:

- What the user did.
- What the application did.
- What it should have done.
- Whether this is a runtime error, type/build/lint failure, data issue, or wrong business behavior.

Do not treat the stack trace as the full problem statement; the visible error may be a symptom.

### 2. Trace the path

Inspect the relevant component, hook, service, domain function, type/schema, tests, and callers. Identify where state enters, changes, persists, and returns to the UI. Check Git diff/history when available and useful.

### 3. Identify root cause and blast radius

Before editing, report briefly:

- Most likely root cause and evidence.
- Files that need to change.
- Shared consumers or dependent features.
- The existing behaviors/contracts at risk.
- The smallest safe fix and how it will be verified.

If evidence is insufficient, do targeted inspection instead of inventing an implementation.

### 4. Make a minimal patch

- Do not refactor unrelated code in the same patch.
- Do not replace an entire file if a focused function-level edit is sufficient.
- Preserve function signatures, component props, hook return values, database field meanings, sort order, and side effects unless changing them is necessary.
- Avoid “fixes” that hide the error by swallowing exceptions, returning fake defaults, removing validation, skipping authorization, or weakening types.
- If a contract must change, identify every consumer and update them deliberately.

### 5. Verify the direct behavior

Run the most relevant targeted test first, then the project's type-check, lint, test, and build scripts as available. Add a regression test or explain why it cannot reasonably be automated. Never invent script names: inspect `package.json` and repository documentation.

### 6. Check for regressions

Review adjacent paths, including applicable cases below:

- Normal success path
- Empty/missing data
- Invalid input
- Unauthorized user
- Duplicate clicks/retries
- Slow or failed network/backend request
- Async race or stale response
- Unmount/navigation during a request or listener
- Existing ordering, filtering, pagination, and notifications
- Mobile layout and accessibility where UI changed

Not every item applies to every change; state which ones were checked.

### 7. Inspect the final diff

Look for unrelated formatting churn, removed conditions, changed return shapes, unhandled promise rejections, missing effect cleanup, duplicate database writes, console-only errors, unsafe casts, exposed technical messages, or new permissions gaps.

### 8. Report accurately

Use this format:

- **Root cause:** ...
- **Fix:** ...
- **Regression checks:** ...
- **Commands and results:** ...
- **Not verified / residual risks:** ...

Do not claim the application is fully fixed when only compilation was checked.

## Stop-and-escalate conditions

Pause before making broad edits if a fix appears to require a database schema migration, destructive data change, changed permission model, changed public API, or rewritten core workflow. Explain the trade-off and implement only when the task's intent supports it. For ordinary coding requests, make the best safe progress without unnecessary questions.
