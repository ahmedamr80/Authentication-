# Performance Optimization Without Regressions

## Start with evidence

1. Identify a measurable symptom: slow route, laggy interaction, unnecessary render, large bundle, repeated request, or expensive query.
2. Profile or instrument the affected path if practical.
3. Record the baseline and expected improvement.
4. Make one focused change at a time and compare before/after.

Do not make broad changes based only on a hunch that code “could be faster.”

## React guidance

- Keep state as close as practical to the components that need it.
- Avoid effects that duplicate derived state or orchestrate ordinary data flow.
- Use `memo`, `useMemo`, and `useCallback` when a measured cost or a clear identity-sensitive API justifies them—not by default.
- Split large routes/components when it reduces initial bundle or meaningfully improves maintainability/performance.
- For large lists, consider pagination or virtualization. Preserve sorting, focus, selection, keyboard navigation, and scroll behavior.
- Debounce expensive type-ahead queries when appropriate, but show responsive UI feedback and do not lose the latest query result.

## Backend and Firestore guidance

- Request only the data required by the screen.
- Use appropriate filters, indexes, pagination, and bounded queries.
- Avoid N+1 read patterns and duplicate listeners.
- Cache only when the invalidation and freshness policy is clear.
- Do not optimize away authorization checks, data validation, transactions, or consistency guarantees.
- Keep query ordering and waitlist/ranking rules unchanged unless explicitly requested.

## Safety rules

- Performance changes must preserve output, ordering, permissions, observable side effects, and error semantics.
- Do not use memoization to hide a state-management or effect-dependency bug.
- Do not introduce global state, caching, denormalization, or concurrency without assessing consistency and invalidation behavior.
- Avoid unrelated refactoring in a performance patch.

## Optimization report

- **Bottleneck/evidence:** ...
- **Baseline:** ...
- **Change:** ...
- **Expected benefit:** ...
- **Behavioral contracts preserved:** ...
- **Verification and after-measurement:** ...
- **Trade-offs:** ...
