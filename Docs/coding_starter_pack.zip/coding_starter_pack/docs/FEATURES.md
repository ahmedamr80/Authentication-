# Feature Inventory and Behavioral Contracts

> This document must describe the application's real behavior. Replace examples and placeholders; do not leave guessed rules in the final version.

## Purpose and users

- **Application purpose:** [Describe the primary problem the app solves.]
- **User roles:** [Guest, registered user, moderator, admin, etc.]
- **Role permissions:** [Document what each role can read, create, edit, delete, approve, or administer.]

## Feature register

For each major feature, document the following:

### Feature: [Name]

- **Entry points:** [Routes/pages/buttons/events that start the flow]
- **Main user journey:** [Step-by-step behavior]
- **Preconditions:** [Authentication, permissions, status, required data]
- **Success behavior:** [State updates, navigation, notifications, timestamps]
- **Failure behavior:** [Validation, permissions, network/backend failure]
- **Data read:** [Collections/tables/API endpoints and fields]
- **Data written:** [Documents/rows/fields, side effects]
- **Adjacent features:** [Other features that share this logic or data]
- **Invariants that must never be broken:** [Rules that must always remain true]
- **Existing tests:** [Test filenames or `None`]

## Cross-feature invariants

List global rules, such as:

- A user without the required permission must never perform a protected action, even if they call the endpoint directly.
- Deleting a parent record must follow the documented policy for dependent records, notifications, and audit history.
- Lists must retain their specified ordering and pagination behavior.
- Retrying an action must not create duplicates unless duplicates are part of the design.
- Loading, empty, error, and success states must remain distinguishable.

## Change-impact checklist

Before changing shared logic, check whether the change affects:

- [ ] Authentication and authorization
- [ ] Form validation and submission
- [ ] Data reads, writes, schema, and indexes
- [ ] Real-time listeners and cleanup
- [ ] Sorting, filtering, pagination, and search
- [ ] Notifications, emails, and other side effects
- [ ] Navigation, deep links, and browser refresh
- [ ] Loading, empty, error, and retry states
- [ ] Mobile/responsive layout and accessibility
- [ ] Admin and non-admin behavior

## Decision log

| Date | Decision | Reason | Affected features |
|---|---|---|---|
| [YYYY-MM-DD] | [Decision] | [Reason] | [Features] |
