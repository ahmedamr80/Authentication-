# Coding Standards

## General

- Match the existing style and patterns unless they are demonstrably causing a problem.
- Prefer clear, boring code over clever abstractions.
- Use meaningful domain names. Avoid generic names such as `data2`, `temp`, or `handleThing` when a precise name is available.
- Keep functions focused; extract helpers when doing so makes logic easier to test or reuse, not simply to reduce line count.
- Add comments to explain non-obvious intent, invariants, or constraints—not to narrate every line.

## TypeScript

- Give public functions and reusable hooks clear input and return types when inference is not sufficiently clear.
- Prefer discriminated unions and `unknown` with narrowing over `any`.
- Validate untrusted data at system boundaries; TypeScript types alone do not validate Firestore/API data at runtime.
- Avoid `as` casts and non-null assertions unless a checked invariant justifies them.
- Avoid silent fallback values that make invalid or missing data look valid.
- Keep API/database document types separate from UI view models when their shapes or responsibilities differ.

## Components and business logic

- Keep components focused on rendering and user interaction.
- Put multi-step business rules in named functions/services that can be tested independently.
- Keep generic shared UI free of feature-specific business rules.
- Avoid duplicating critical business logic across multiple components. Share it through a trusted domain/service layer.
- Do not assume the client is trusted for authorization or data integrity.

## Dependencies and refactoring

- Do not add a dependency when a small, maintainable local solution is enough.
- Do not upgrade packages during an unrelated bug fix.
- Refactor incrementally and keep behavior-preserving changes separate from behavior changes where practical.
- Update types, tests, and documentation whenever a real public contract changes.

## Async and cleanup

- Handle rejected promises intentionally.
- Do not leave timers, event listeners, subscriptions, or observers active after their owner is gone.
- Distinguish expected failures (validation, permission denied) from unexpected failures (programming or infrastructure problems).
- Avoid swallowing errors. Convert them to a useful UI state and keep appropriate diagnostic details in safe logs.
