# React Hooks Guidelines

## Rules of Hooks

- Call React Hooks only at the top level of function components or custom Hooks.
- Do not call Hooks inside conditions, loops, nested functions, `try` blocks, or after an early return.
- Custom Hook names begin with `use` and communicate a specific capability, such as `useEvent`, `useAuth`, or `useOnlineStatus`.

## Design custom Hooks

- Create a custom Hook when it makes reusable stateful logic or synchronization clearer. Do not create a Hook for every tiny abstraction automatically.
- Make inputs and return values explicit and stable. Document meaningful states, such as `loading`, `error`, `data`, and `refetch`.
- Remember that calling the same custom Hook in two components shares the logic, not the actual state instance. Use context or a shared store only when shared state is intended.
- Keep rendering and presentation out of data hooks. Put Firestore access in the existing service/repository layer if the app uses one.
- Avoid “generic lifecycle hooks” such as `useMount` that obscure what external system is being synchronized.

## `useEffect`

- Use an Effect to synchronize with an external system: subscriptions, browser APIs, timers, imperative third-party widgets, or similar.
- Do not use an Effect merely to calculate derived render data or respond to a button click. Calculate derived data during render or perform the action in the event handler.
- Ensure dependencies match the reactive values used. Do not suppress the dependency linter as a shortcut.
- Return cleanup for subscriptions, listeners, timers, and observers.
- For async reads, account for stale responses and component lifecycle. Where appropriate, unsubscribe, abort the request, or ignore obsolete results.
- Treat development Strict Mode's extra setup/cleanup cycle as a test of cleanup correctness, not as a reason to disable Strict Mode.

## Data subscriptions (e.g. Firestore)

- Keep one clear owner for each listener where possible.
- Store and invoke the unsubscribe function during cleanup.
- Prevent duplicate listeners across renders.
- Define behavior for permission errors, transient errors, deleted documents, empty results, and reconnects.
- Do not silently replace a failed read with an empty result if that would mislead the user.

## State and dependencies

- Keep a single source of truth where practical; avoid duplicated state that can get out of sync.
- Use functional state updates when the next value depends on the previous value.
- Do not add `useMemo` or `useCallback` everywhere. Use them when profiling or a clear referential-stability requirement justifies them.
- Avoid object/function dependency churn by structuring code clearly before reaching for memoization.

## Hook review checklist

- [ ] Hook is called at the top level.
- [ ] Dependencies are correct and not suppressed without a documented reason.
- [ ] Async state cannot be overwritten by an obsolete request.
- [ ] Subscription/timer/listener cleanup is present.
- [ ] Loading, empty, success, and error states are distinguishable.
- [ ] Multiple consumers behave as intended.
- [ ] Existing hook return shape and consumers remain compatible.
