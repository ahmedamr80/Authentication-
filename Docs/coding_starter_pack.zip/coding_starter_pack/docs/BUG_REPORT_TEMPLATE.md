# Bug Report for Coding AI

> Fill in what you know. Leave unknown fields blank rather than guessing. Include the full error text, with secrets/tokens/personal data removed.

## 1. What I was doing

- **Feature/page:**
- **User role/state:**
- **Steps to reproduce:**
  1.
  2.
  3.

## 2. Expected vs actual behavior

- **Expected:**
- **Actual:**
- **Frequency:** Always / Sometimes / Once / Unknown
- **When it started:**

## 3. Error evidence

```text
Paste the full console/build/test error or stack trace here.
Remove passwords, access tokens, secret keys, and sensitive user information.
```

## 4. Environment

- **Branch/commit (if known):**
- **Browser/device (if relevant):**
- **Command that failed (if relevant):**
- **Recent related change (if known):**

## 5. Files and context

- **Files I suspect (optional):**
- **Related feature documentation:**
- **Relevant code/logs:** [Attach or paste exact snippets if the coding agent cannot inspect the repository.]

## 6. Must preserve

List important nearby functionality and contracts that must not change. Examples: permissions, database fields, waitlist ordering, search behavior, notifications, routes, return types, loading/error states.

- 

## 7. Instructions to the coding agent

Follow `AGENTS.md` and `docs/BUG_FIX_PROTOCOL.md`. Inspect the existing code first, find the root cause, make the smallest safe fix, add/update a regression test where practical, and verify adjacent behavior. Do not perform unrelated refactoring. Report exactly which checks were run and which were not.
