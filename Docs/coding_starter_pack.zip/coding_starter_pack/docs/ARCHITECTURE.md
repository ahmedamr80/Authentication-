# Application Architecture

> Document the code that exists today. This file is a map, not an instruction to redesign the project.

## Stack

- Frontend: [React version, TypeScript, Vite, router, UI library]
- Backend/data: [Firebase Auth, Firestore, Functions, REST APIs, etc.]
- State/data-fetching: [Existing approach]
- Tests: [Existing framework]
- Deployment: [Hosting/CI]

## Main boundaries

Describe the intended responsibilities of each layer:

- **Pages/routes:** route composition, page-level state and layout.
- **Feature components:** UI for a specific business capability.
- **Hooks:** reusable stateful React behavior and synchronization with external systems.
- **Services/repositories:** data access, subscriptions, API calls, and persistence.
- **Domain functions:** business rules that can be tested without rendering the UI.
- **Types/schemas:** shared contracts and input validation.
- **Shared UI:** generic components that do not contain feature-specific business rules.

## Data-flow map

For a typical user action, document the flow, for example:

`Page/Component -> Feature Hook or Action -> Domain Validation -> Service/Repository -> Backend -> Result -> UI State`

Record where authorization is enforced. Client-side checks improve the experience but must not replace trusted backend authorization.

## State ownership

For each key state value, identify its source of truth:

| State/data | Source of truth | Read through | Modified through | Consumers |
|---|---|---|---|---|
| [Example] | [Backend or local UI] | [Hook/service] | [Action/service] | [Features] |

Avoid copying the same server state into multiple local stores without a documented reason.

## Critical contracts

Document:

- Stable TypeScript types and public function signatures.
- Backend collection/table schemas, field meanings, required indexes, and security rules.
- Route paths and authorization requirements.
- Ordering/pagination rules.
- Transactions, batches, and multi-step workflows.
- Real-time listener ownership and cleanup.
- Notification or analytics side effects.

## Architecture change rule

Before changing a shared layer, list its consumers and explain the impact. Prefer a focused change with a migration plan over a broad rewrite. Update this document when the architecture actually changes.
