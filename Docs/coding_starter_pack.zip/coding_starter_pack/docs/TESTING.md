# Testing and Regression Strategy

## Testing principles

- Test observable behavior and business rules, not implementation details alone.
- Every fixed bug should gain a regression test when practical.
- Preserve existing tests unless the intended product behavior changed deliberately.
- Test shared logic at the lowest practical layer and add a small number of UI/integration tests for important end-to-end flows.
- Tests must not depend on production data, real user accounts, or non-deterministic network behavior.

## Verification ladder

1. **Focused test:** target the changed function/component/flow.
2. **Type-check:** verify TypeScript contracts and imports.
3. **Lint/static checks:** check project rules.
4. **Related tests:** run tests for the affected feature and its consumers.
5. **Build:** verify the production build.
6. **Manual smoke test:** verify critical user flows when automated coverage is insufficient.

Use the commands actually defined by the project. For a Vite project, inspect `package.json` before assuming whether scripts such as `typecheck`, `lint`, `test`, or `build` exist.

## Regression matrix template

| Scenario | Expected result | Verified? | Evidence/test |
|---|---|---|---|
| Normal success path | [Expected] | [Yes/No] | [Test/command] |
| Invalid input | [Expected validation] | [Yes/No] | [Test/command] |
| Missing/empty data | [Expected empty state] | [Yes/No] | [Test/command] |
| Unauthorized action | [Access denied] | [Yes/No] | [Test/command] |
| Backend/network failure | [Recoverable error] | [Yes/No] | [Test/command] |
| Retry/double submission | [No duplicate side effects] | [Yes/No] | [Test/command] |
| Adjacent feature A | [Unchanged behavior] | [Yes/No] | [Test/command] |

## Tests for Firestore-backed features

Where relevant, verify:

- Correct document IDs and field names.
- Query filters, ordering, pagination, and required indexes.
- Duplicate-write prevention and transaction consistency.
- Security rules and role-based access.
- Subscription setup and unsubscribe cleanup.
- Behavior when a document is deleted or changed during an active view.
- No secrets or personal data leak into test output.

Use emulators/mocks appropriate to the current project; do not silently introduce an entirely new test stack for a small bug.

## Definition of done

A change is done when the intended behavior is reproduced as working, important adjacent behavior is checked, relevant automated checks have been run or explicitly marked unavailable, and the final diff contains no unexplained unrelated changes.
