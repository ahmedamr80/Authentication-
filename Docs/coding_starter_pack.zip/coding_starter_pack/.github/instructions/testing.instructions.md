---
applyTo: "**/*.{test,spec}.{ts,tsx,js,jsx}"
---

When editing tests:

- Follow `docs/TESTING.md`.
- Test user-visible behavior and business invariants, not just implementation details.
- Add a regression test for the reported bug when practical.
- Do not weaken tests merely to make a broken implementation pass.
- Cover the relevant success and failure paths, permissions, retries/duplicates, and boundary conditions.
- Use the project's existing test framework and conventions.
