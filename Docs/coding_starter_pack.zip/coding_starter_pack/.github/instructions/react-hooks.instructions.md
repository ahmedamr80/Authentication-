---
applyTo: "src/**/*.{ts,tsx}"
---

When editing React components or hooks:

- Follow `docs/HOOKS_GUIDELINES.md` and the React Rules of Hooks.
- Call Hooks only at the top level of function components or custom Hooks.
- Use `useEffect` for synchronization with external systems, not derived render data or ordinary user-event logic.
- Keep effect dependencies correct; do not silence exhaustive-deps without demonstrating why it is safe.
- Clean up subscriptions, timers, event listeners, and observers.
- Preserve hook signatures and return shapes; inspect all callers before changing them.
- Handle loading, empty, error, and stale async results explicitly.
- Avoid premature `useMemo`/`useCallback`; optimize only for a clear reason.
