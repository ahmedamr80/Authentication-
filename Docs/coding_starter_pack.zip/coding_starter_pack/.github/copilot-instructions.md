# Repository-wide Coding Instructions

These are the core rules for GitHub Copilot. Keep this file aligned with the project-root `AGENTS.md` to avoid conflicting instructions.

- Preserve existing behavior. Fix the root cause with the smallest safe change.
- Read `AGENTS.md`, `docs/FEATURES.md`, and relevant sections of `docs/ARCHITECTURE.md` before changing existing behavior.
- Do not mix unrelated refactoring or dependency upgrades into a bug fix.
- Inspect callers and consumers before changing shared functions, hooks, types, routes, or database contracts.
- Add or update regression tests when practical. Run the repository's actual type-check, lint, test, and build scripts as applicable.
- Never claim checks passed unless you ran them. State what was not tested.
- Preserve security, authorization, data integrity, loading/error states, ordering, and side effects.
- Do not expose stack traces, secrets, raw backend errors, or sensitive data to users.
