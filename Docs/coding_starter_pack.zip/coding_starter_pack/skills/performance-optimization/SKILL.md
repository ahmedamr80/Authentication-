---
name: performance-optimization
description: Optimize React, TypeScript, browser, or backend performance based on a real bottleneck without changing observable behavior, ordering, security, or data integrity.
---

# Performance Optimization Workflow

1. Describe the performance symptom and identify the affected route, interaction, query, list, or build output.
2. Measure or profile the current behavior when practical. Do not optimize solely because code looks inefficient.
3. Trace downstream consumers and document the contracts the change must preserve: data shape, ordering, permissions, side effects, focus/keyboard behavior, and error semantics.
4. Choose the smallest optimization that addresses the measured bottleneck.
5. Avoid unrelated refactoring, package upgrades, global state, caching, denormalization, or concurrency unless the benefit and consistency trade-offs are explicit.
6. In React, avoid unnecessary state/effects and use memoization only when justified. For large lists, consider pagination or virtualization while preserving user interaction.
7. For backend queries, preserve filters, ordering, access checks, transactions, and pagination semantics. Avoid over-fetching and duplicate listeners.
8. Run regression tests and compare the result against the baseline when possible.
9. Report evidence, baseline, change, measured/expected benefit, behavior preserved, test results, and trade-offs.

## Hard rules

Never trade away correctness, authorization, data integrity, or a documented business rule for a performance gain without the user explicitly approving the behavior change.
