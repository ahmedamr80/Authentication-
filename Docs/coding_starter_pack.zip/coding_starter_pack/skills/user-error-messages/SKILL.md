---
name: user-error-messages
description: Create or improve user-facing validation, network, permission, business-rule, and unexpected-error messages while keeping technical diagnostics safe and useful.
---

# Error Message Workflow

1. Identify the real failure category: validation, unauthenticated, forbidden, not found, conflict/business rule, network, or unexpected internal failure.
2. Write a brief message in plain language that explains what happened at the level the user needs.
3. Provide a useful next step when possible: correct a field, sign in, request access, refresh, or retry when safe.
4. Do not claim that an action succeeded until success is confirmed by the backend.
5. Preserve user input where appropriate. Distinguish an empty successful result from a failed request.
6. Do not expose stack traces, raw exception text, internal paths, database queries, security-rule details, access tokens, or secrets.
7. Keep diagnostics separate from the user message. Log useful, sanitized technical context only through an approved logging path.
8. Ensure retry behavior cannot accidentally duplicate writes, registrations, invitations, notifications, payments, or other side effects.
9. Test both the visible message and the actual recovery behavior.

## Quality test

A user should understand what happened, whether their action may have succeeded, and what safe next step to take. A developer should be able to investigate through restricted diagnostics without sending stack traces to the user.
