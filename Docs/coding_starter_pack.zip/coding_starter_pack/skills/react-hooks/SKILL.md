---
name: react-hooks
description: Design, review, debug, or refactor React Hooks and hook-consuming components, including effects, async requests, subscriptions, stale state, dependency arrays, and custom hooks.
---

# React Hooks Workflow

1. Inspect the component and every consumer of the hook before changing its signature or return shape.
2. Follow the Rules of Hooks: call Hooks only at the top level of function components or custom Hooks.
3. Use `useEffect` to synchronize with an external system. Do not use it just to derive render data or respond to user events.
4. Keep dependencies aligned with reactive values read by the effect. Do not silence dependency lint errors without a demonstrated and documented reason.
5. Add cleanup for listeners, timers, observers, and subscriptions. For async work, prevent stale responses from overwriting newer state when relevant.
6. Make loading, success, empty, and error states explicit where the operation needs them. Do not disguise a failed query as a valid empty result.
7. Put backend interactions in the existing service/repository layer when the project follows that pattern.
8. Avoid automatic memoization. Use `useMemo`/`useCallback` when there's a concrete performance or referential-stability reason.
9. Preserve hook contracts and the behavior of every known consumer. Add tests for important edge cases.
10. Run relevant tests and static checks, and report actual results.

## Review checklist

- Hook called at top level?
- Correct dependencies and no unexplained linter suppression?
- Cleanup present?
- Async races and repeated subscriptions addressed?
- Multiple consumers behave as expected?
- Existing return shape and consumer behavior preserved?
