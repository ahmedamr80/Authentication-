---
name: bug-fixing
description: Diagnose and fix bugs in an existing codebase while preserving business rules, interfaces, data integrity, and adjacent features. Use whenever a user provides an error, regression, failing test, or unexpected behavior.
---

# Bug Fixing Workflow

1. Read the project `AGENTS.md`, relevant feature documentation, and architecture notes.
2. Reproduce or clearly define the reported behavior. Separate the observed symptom from the suspected root cause.
3. Inspect the exact source code, callers, consumers, types/schemas, tests, and related services. Do not invent repository details.
4. Before editing, identify the likely cause, the smallest safe change, affected files, and the adjacent features most at risk.
5. Make a targeted fix. Do not add unrelated refactoring, rename public contracts, alter data shape, remove validation, swallow exceptions, or weaken authorization just to make the error disappear.
6. Add or update a regression test when practical. Include relevant boundary and failure paths.
7. Run the actual available test, type-check, lint, and build commands. Inspect `package.json` or the project docs rather than guessing script names.
8. Review the diff for unrelated changes, changed return values, missing cleanup, duplicate writes/notifications, race conditions, and changed UI states.
9. Report root cause, files changed, behavior preserved, checks actually run, results, and what remains unverified.

## Hard rules

- A disappearing error is not enough: the intended behavior must work and relevant adjacent behavior must be checked.
- Preserve behavior unless the user explicitly requests a behavior change.
- Never claim a test passed unless it was run and passed.
- If the fix requires a data migration, destructive change, broad API change, or permission-model change, explain the risk and avoid silently proceeding with a broad rewrite.
