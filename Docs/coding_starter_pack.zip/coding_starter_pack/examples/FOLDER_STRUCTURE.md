# Example Folder Structure: React + TypeScript + Vite + Firebase

This is a scalable example for a small-to-medium single-page application. It is not a reason to reorganize an established app automatically. Preserve the project's current conventions and migrate incrementally only when there is a clear benefit.

```text
my-app/
├── public/                         # Static public files
├── docs/
│   ├── FEATURES.md                 # Behavioral contracts and business rules
│   ├── ARCHITECTURE.md             # Boundaries, data flow, state ownership
│   ├── BUG_FIX_PROTOCOL.md
│   ├── TESTING.md
│   └── ...
├── .github/
│   ├── copilot-instructions.md     # Optional, for GitHub Copilot
│   └── instructions/
│       ├── react-hooks.instructions.md
│       └── testing.instructions.md
├── .cursor/
│   └── rules/                      # Optional Cursor-specific .mdc rules
├── src/
│   ├── app/
│   │   ├── App.tsx                 # App shell
│   │   ├── router.tsx              # Route definitions
│   │   └── providers/              # Auth/query/theme providers
│   ├── routes/                     # Route-level pages, if separate from features
│   ├── features/
│   │   ├── events/
│   │   │   ├── components/         # Event-specific UI components
│   │   │   ├── hooks/              # Event-specific React hooks
│   │   │   ├── services/           # Feature-level data access/orchestration
│   │   │   ├── domain/             # Business rules, pure functions
│   │   │   ├── types.ts            # Feature-specific contracts
│   │   │   ├── schemas.ts          # Runtime input validation, if used
│   │   │   └── __tests__/          # Tests near the feature
│   │   ├── registrations/
│   │   ├── players/
│   │   └── admin/
│   ├── shared/
│   │   ├── components/             # Generic buttons, dialogs, fields
│   │   ├── hooks/                  # Truly cross-feature hooks
│   │   ├── services/               # Shared APIs and integrations
│   │   ├── types/                  # Cross-feature types only
│   │   └── utils/                  # Pure utilities used across features
│   ├── lib/
│   │   └── firebase/
│   │       ├── client.ts           # Firebase initialization
│   │       └── converters.ts       # Shared data converters, if appropriate
│   ├── styles/
│   ├── main.tsx
│   └── vite-env.d.ts
├── functions/                      # Firebase Cloud Functions, if used
│   └── src/
│       ├── features/
│       └── index.ts
├── tests/                          # Optional cross-feature/integration tests
├── .env.example                    # Names/placeholders only; never real secrets
├── eslint.config.js
├── package.json
├── tsconfig.json
├── vite.config.ts
└── AGENTS.md
```

## Boundary rules

- Put a component in `features/<feature>/components/` if it represents that feature's UI. Put it in `shared/components/` only when it is generic and reused across features.
- Put a hook in the feature folder if it serves one feature; use `shared/hooks/` only for genuinely cross-feature behavior.
- Put backend reads/writes in existing service/repository patterns. Do not scatter Firestore calls across every component.
- Put testable business rules in pure functions when practical. UI components should not be the only place where an important rule exists.
- Avoid circular imports between features. Shared modules should not depend on feature modules.
- Use one source of truth for types where practical; do not duplicate slightly different definitions of the same backend shape.
- For a very small app, combine folders rather than creating empty layers. Add structure when actual complexity requires it.

## Example feature slice

```text
src/features/registrations/
├── components/
│   ├── RegistrationForm.tsx
│   └── RegistrationStatus.tsx
├── hooks/
│   └── useRegistration.ts
├── services/
│   └── registrationService.ts
├── domain/
│   ├── canRegister.ts
│   └── registrationRules.ts
├── types.ts
└── __tests__/
    ├── canRegister.test.ts
    └── registrationService.test.ts
```

A simple request path could be:
`RegistrationForm -> useRegistration -> registrationService -> Firestore -> typed result -> UI state`.

Keep permissions and integrity checks in the trusted backend/security rules too; a hidden or disabled button is not sufficient protection.
