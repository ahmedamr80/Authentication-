# Coding Agent Instructions

## 1. Highest priority: preserve behavior

When fixing, changing, or optimizing existing code, preserve all existing functionality unless the user explicitly asks to change it. The reported error is not permission to redesign nearby code.

- Read the relevant feature and architecture documentation before editing.
- Treat current business rules, permission checks, data shapes, side effects, navigation, notifications, ordering, and loading/empty/error states as contracts.
- Trace the affected call chain and dependencies before changing code. Identify callers, consumers, shared state, database writes, and other features that may rely on the behavior.
- Prefer the smallest complete fix. Do not mix unrelated cleanup, renaming, dependency upgrades, or refactoring into a bug fix.
- Never remove logic because it looks redundant until you understand why it exists and verify it is safe to remove.
- Do not weaken security, authorization, validation, data integrity, or error handling to make a test pass.

## 2. Required workflow for a bug fix

1. **Understand:** restate the observed behavior, expected behavior, and suspected root cause.
2. **Inspect:** locate the source, callers, related services/hooks/types, and existing tests. Do not guess at code that has not been inspected.
3. **Map regression risks:** list the adjacent behaviors that could be affected.
4. **Plan a targeted change:** explain the intended change briefly. If the issue is ambiguous, identify assumptions rather than silently inventing behavior.
5. **Implement:** make the narrowest complete patch. Preserve public interfaces and data contracts unless a change is required and explicitly explained.
6. **Verify:** run relevant tests, type-check, lint, and build commands that exist in this repository. Add or update regression tests where practical.
7. **Review the diff:** look for unrelated edits, changed return shapes, changed query ordering, missing cleanup, swallowed errors, permission bypasses, duplicate side effects, and unintended UI changes.
8. **Report honestly:** state files changed, root cause, behavior preserved, commands actually run, results, and anything not verified.

## 3. Never claim unverified success

- Do not say tests pass unless they were run and passed.
- If a check could not run, say why and give the exact command for the user to run.
- Do not claim to have inspected files or dependencies that were not available.
- Do not invent package scripts, APIs, environment variables, database fields, or schema details. Inspect the repository first.

## 4. Code and architecture standards

- Follow existing project conventions unless they are causing the issue or the user requests a change.
- Use TypeScript types that reflect actual data. Avoid `any`, unsafe casts, and non-null assertions unless justified locally.
- Keep UI components focused on rendering and interaction; keep reusable business logic in feature services or domain functions.
- Keep Firebase reads/writes and subscriptions out of UI components when the project already uses service modules.
- Preserve existing API, component prop, hook return, route, and database document contracts unless a deliberate migration is part of the task.
- Do not add dependencies for a small problem without explaining why a dependency is needed.
- Avoid broad changes to shared components or shared hooks without checking all important consumers.

## 5. Data integrity, security, and async work

- Validate user-controlled input at the appropriate boundary.
- Enforce authorization in trusted server/backend rules as well as the UI; hiding a button is not authorization.
- Do not expose secrets, tokens, stack traces, raw database errors, or sensitive user data in UI messages or logs.
- For async work, handle loading, success, empty, error, retry, cancellation/stale responses, and cleanup as applicable.
- For real-time subscriptions, unsubscribe on cleanup and avoid duplicate listeners.
- Avoid duplicate writes, duplicate notifications, and partial multi-step updates. Use transactions/batches where the data model and backend support them.

## 6. Tests and regression protection

- Find existing test commands and patterns before adding new tooling.
- Add a regression test for the reported failure when feasible.
- Test the changed behavior and the most likely adjacent failure paths.
- For business-critical flows, check both success and failure cases, authorization, duplicate actions, and boundary conditions.
- Never update a test merely to agree with a broken implementation. Change expectations only when the intended behavior has deliberately changed.

## 7. Communication format

For a non-trivial task, report:

- **Root cause:** what actually caused the issue.
- **Change:** what was changed and why this is the smallest safe fix.
- **Preserved behavior:** relevant features/contracts checked.
- **Verification:** commands run and actual results.
- **Residual risks:** anything not tested or requiring manual confirmation.

For a simple task, keep the report brief, but do not omit material caveats.
