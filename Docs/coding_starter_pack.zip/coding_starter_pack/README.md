# AI Coding Engineering Starter Pack

A practical instruction set for AI-assisted development. It is designed to reduce regressions when generating code, fixing errors, or optimizing an existing React + TypeScript application. The examples assume Vite and Firebase, but the rules can be adapted to other stacks.

## Recommended installation

1. Read `AGENTS.md`. Keep it short enough that the coding agent can consistently follow it.
2. Copy `docs/FEATURES.md` and `docs/ARCHITECTURE.md` into your repository and fill them in with the *actual* application behavior and architecture.
3. Keep the remaining documents under `docs/` and refer to them from `AGENTS.md` when relevant.
4. If your tool supports a specific instruction format, install the matching example from `.github/` or `.cursor/`. Do not assume every coding tool reads every file format.
5. Commit these documents to Git. Update them when behavior or architecture changes.

## The most important rule

**A bug fix is not complete merely because the reported error disappears. It is complete only when the intended behavior works and relevant existing behavior has been checked for regressions.**

## Instructions vs. skills

- `AGENTS.md` and editor-specific rule files set persistent project expectations.
- A `SKILL.md` lives in a named skill directory and defines a repeatable workflow for a particular task, such as bug fixing, React Hooks, or performance optimization. The open Agent Skills format requires YAML frontmatter with `name` and `description`; compatibility depends on the coding tool.

## How to use this pack

- For every coding request: the agent follows `AGENTS.md` and checks feature/architecture docs.
- For a bug: submit `docs/BUG_REPORT_TEMPLATE.md`; require the workflow in `docs/BUG_FIX_PROTOCOL.md`.
- Before merging or deploying: follow `docs/TESTING.md`.
- Before a refactor or optimization: follow `docs/PERFORMANCE.md` and explicitly preserve public behavior.

## Important setup note

The folder structure in `examples/FOLDER_STRUCTURE.md` is a proposal, not a requirement to reorganize an existing app. For an existing codebase, map its real structure first and make incremental changes. Do not move files just to match the example.

## Reference material

- AGENTS.md format and examples: https://agents.md/ and https://github.com/agentsmd/agents.md
- GitHub Copilot repository instructions: https://docs.github.com/en/copilot/how-tos/copilot-in-your-ide/customize-copilot/configure-custom-instructions/add-repository-instructions-in-your-ide
- Cursor rules: https://cursor.com/docs/rules
- React Rules of Hooks: https://react.dev/reference/rules/rules-of-hooks
- React custom Hooks: https://react.dev/learn/reusing-logic-with-custom-hooks
- React useEffect guidance: https://react.dev/reference/react/useEffect
- OWASP Error Handling Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Error_Handling_Cheat_Sheet
- OWASP Logging Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html

- Agent Skills format and specification: https://agentskills.io/specification
